package com.company;
import ij.plugin.filter.PlugInFilter;
import ij.ImagePlus;
import ij.process.ImageProcessor;
import ij.process.ByteProcessor;
import ij.IJ;
import ij.plugin.PlugIn;
import ij.process.ColorProcessor;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Random;
import ij.plugin.filter.PlugInFilter;
import ij.ImagePlus;
import ij.process.ImageProcessor;
import ij.process.ByteProcessor;
import ij.IJ;

public class Adjust5 implements PlugInFilter {

    String title;
    double a1 = 121.534;
    double a2 = 69.199;
    double sig1 = 55.697;
    double sig2 = 42.526;

    public int setup(String args, ImagePlus im) {
        title = im.getShortTitle();
        return DOES_8G;
    }

    public void run(ImageProcessor inputIP) {
        int height = inputIP.getHeight();
        int width = inputIP.getWidth();
        int col, row;

        int lowa1 = (int) (a1 - sig1);
        int higha1 = (int) (a1 + sig1);

        int lowa2 = (int) (a2 - sig2);
        int higha2 = (int) (a2 + sig2);



        ImageProcessor outputIP = new ByteProcessor(width, height);


        for (col = 0; col < width; col++){
            for(row = 0; row < height; row++)
                outputIP.putPixel(col, row, lowa1 + (int)(inputIP.getPixel(col, row) - lowa2) * (higha1 - lowa1) / (higha2 - lowa2));

        }


        (new ImagePlus("4adjust.jpeg" , outputIP)).show();

    }
}
