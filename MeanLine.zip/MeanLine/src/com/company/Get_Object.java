package com.company;

import ij.plugin.filter.PlugInFilter;
import ij.ImagePlus;
import ij.process.ImageProcessor;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
//import ij.process.ByteProcessor;
//import ij.IJ;

import java.awt.Rectangle;

public class Get_Object1 implements PlugInFilter {

    String title;
    private String path = "/Users/gurgenhakobyan/Desktop/HomeWork1/";

    public int setup(String args, ImagePlus im) {
        title = im.getShortTitle();
        return DOES_RGB;
    }

    public void run(ImageProcessor inputIP) {
        Rectangle erasable = inputIP.getRoi(); // get cordinate of selected part
        try {

            FileWriter output = new FileWriter(path + title + ".txt");
            output.write(" " + ((int)erasable.getX() + " " + ((int) erasable.getY()) + " " + ((int) erasable.getWidth()) + " "+ ((int) erasable.getHeight())));
            output.flush();
        }
        catch (IOException e) {

        }
        catch (Exception e) {

        }


    }
}

