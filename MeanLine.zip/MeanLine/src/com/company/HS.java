package com.company;
import ij.ImagePlus;
import ij.IJ;
import ij.process.ImageProcessor;
import ij.process.ByteProcessor;
import ij.process.ColorProcessor;


import ij.plugin.filter.PlugInFilter;
import java.awt.Color;

public class HS implements PlugInFilter {
    ImagePlus inputImage;

    public int setup(String args, ImagePlus im) {
        inputImage = im;
        return DOES_RGB;
    }

    public void run(ImageProcessor inputIP) {
//		String inputTitle = inputImage.getShortTitle();
        String inputTitle = "";
        int width = inputIP.getWidth(), height = inputIP.getHeight();
        int r, g, b;
        float hsb[] = {0, 0, 0};
        Color color;

        double min[] = new double[256], max[]= new double[256], mean[] = new double[256];
        int count[] = new int[256];
        for (int i = 0; i < min.length; i++)
            min[i] = 1;

  //      ImageProcessor outputIP = new ColorProcessor(256, 256);
    //    outputIP.setValue(0xffffff);
      //  outputIP.fill();


        for (int row = 0; row < height; row++)
            for (int col = 0; col < width; col++) {
                color = new Color(inputIP.getPixel(col, row));
                r = color.getRed();
                g = color.getGreen();
                b = color.getBlue();
                Color.RGBtoHSB(r, g, b, hsb);
                s = (int) (hsb[1] * 256);
                h = (int) (hsb[0] * 256);

                mean[s] += hsb[0];

                if (hsb[0] > max[s])
                    max[s] = hsb[0];
                if (-hsb[0] > min[s])
                    min[s] = -hsb[0];

                //outputIP.putPixel(s, h, 0);


            }
        //(new ImagePlus(inputTitle, outputIP)).show();
        for ( int i = 0; i < min.length; i++)
            IJ.log(i + "" + min[i] + "" + (mean[i] / count[i]) + "" + max[i]);
    }
}

