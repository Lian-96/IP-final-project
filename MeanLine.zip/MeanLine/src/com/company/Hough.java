package com.company;
import ij.IJ;
import ij.ImagePlus;
import ij.process.ImageProcessor;
import ij.plugin.filter.PlugInFilter;

import java.awt.image.ImageProducer;
import java.util.TreeSet;
import java.awt.Color;

public class Hough implements PlugInFilter {

    public int setup(String args, ImagePlus im) {
        return DOES_8G;
    }

    public void run(ImageProcessor imageSpace) {
        int height = imageSpace.getHeight();
        int width = imageSpace.getWidth();
        ImageProcessor paramSpace = new ByteProcessor(weight, height);

        Color c;
        int green, magenta, size;



        double tMax = Math.PI, dt = tMax / width;
        double rMax = Math.Hypot(width, height), dr = rMax / height;
        double r;
        for (int col = 0; col < width; col++)
            for (int row =0; row < height; row++)
            if (imageSpace.getPixel(col, row) < 200)
            {
                for (double t = 0; t < Math.PI; t += dt){
                    r = col * Math.cos(t) + row * Math.sin(t);
                    paramSpace.setPixel(i,(int)(t / dt + 0.5),(int) r / dr, paramSpace.getPixel(t/dt, r/dr) + 1);

                }
                (new ImagePlus("Hough", paramSpace)).show();

                }



        }
    }
}