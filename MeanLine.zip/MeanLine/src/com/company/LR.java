package com.company;
import ij.ImagePlus;
import ij.process.ImageProcessor;
import ij.process.ColorProcessor;
import ij.plugin.filter.PlugInFilter;


public class LR implements PlugInFilter {
    ImagePlus inputImage;

    public int setup(String args, ImagePlus im) {
        inputImage = im;
        return DOES_RGB;
    }
    public void run(ImageProcessor inputIP) {
        int width = inputIP.getWidth() / 5, height = inputIP.getHeight() / 5;
        ImageProcessor outputIP = new ColorProcessor(width, height);

        for (int row = 0; row < height; row++)
           for (int col = 0; col < width; col++)
             outputIP.putPixel(col, row, inputIP.getPixel(col * 5, row * 5));
        (new ImagePlus(inputImage.getShortTitle() + "LR.jpg",outputIP )).show();

        }

    }




