package com.company;
import ij.plugin.filter.PlugInFilter;
import ij.ImagePlus;
import ij.process.ImageProcessor;
import ij.process.ByteProcessor;
import ij.IJ;
public class Mean_Line2 implements PlugInFilter {

    String title;

    public int setup(String args, ImagePlus im) {
        title = im.getShortTitle();
        return DOES_8G;
    }

    public void run(ImageProcessor inputIP) {
        int height = inputIP.getHeight();
        int width = inputIP.getWidth();
        int col, row;

        ImageProcessor outputIP = new ByteProcessor(width, height);

        for (col = 0; col < width; col++){
            int mcol = 0;
            for(row = 0; row < height; row++){
                mcol += inputIP.getPixel(col, row);
            }

            mcol =  mcol / height;
            for (row = 0; row < height; row++){
                outputIP.putPixel(col, row, mcol);

            }

        }

        (new ImagePlus(title + " with mean line", outputIP)).show();
    }
}
