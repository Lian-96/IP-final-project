package com.company;
import ij.plugin.filter.PlugInFilter;
import ij.ImagePlus;
import ij.process.ImageProcessor;
import ij.process.ByteProcessor;
import ij.IJ;
import ij.plugin.PlugIn;

public class Merge11 implements PlugIn {
    private String leftImage = "/Users/gurgenhakobyan/Desktop/HomeWork1/8match1.jpg/";
    private String rightImage = "/Users/gurgenhakobyan/Desktop/HomeWork1/2dark.jpg/";

    public void run(String s) {
        ImagePlus leftImageP = IJ.openImage(leftImage);
        ImageProcessor leftIP = leftImageP.getProcessor();

        ImagePlus rightImageP = IJ.openImage(rightImage);
        ImageProcessor rightIP = rightImageP.getProcessor();

        int height = leftImageP.getHeight();
        int width = leftImageP.getWidth() + rightImageP.getWidth();

        ImageProcessor mergedIP = new ByteProcessor(width, height);

        for (int row = 0; row < height; row++) {
            for (int col = 0; col < leftImageP.getWidth(); col++) {
                mergedIP.putPixel(col, row, leftIP.getPixel(col, row));
            }
            for (int col = 0; col < rightImageP.getWidth(); col++) {
                mergedIP.putPixel(leftImageP.getWidth() + col, row, rightImageP.getPixel(col, row));
            }
        }

        new ImagePlus("9method3.jpeg", mergedIP).show();
    }
}
