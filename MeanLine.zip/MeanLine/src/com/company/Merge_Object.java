package com.company;

import ij.IJ;
import ij.ImagePlus;
import ij.process.ImageProcessor;
import ij.process.ColorProcessor;
import ij.plugin.PlugIn;
import java.awt.Color;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.io.File;

import java.util.Scanner;

public class Merge_Object implements PlugIn {

    private ImagePlus image1, image2;
    private ImageProcessor ip1, ip2, result;

    private String name1 = "p111", name2 = "p112";
    private String path = "/Users/gurgenhakobyan/Desktop/HomeWork1/";

    public void run(String args) {
        image1 = IJ.openImage(path + name1 + ".jpg");
        ip1 = image1.getProcessor();

        image2 = IJ.openImage(path + name2 + ".jpg");
        ip2 = image2.getProcessor();
        int x= 0, y= 0, width=0, height = 0;

        try {
            Scanner input = new Scanner(new File(path + name1 + ".txt"));

            x = input.nextInt();
            y = input.nextInt();
            width = input.nextInt();
            height = input.nextInt();

        }

        catch (IOException e) {
            IJ.log(e.getMessage());

        }
        catch (Exception e) {
            IJ.log("Exception");

        }


        for (int col = 0; col < x + width; col++)
            for (int row = 0; row < y + height; row++) {
                ip1.putPixel(col, row, ip2.getPixel(col, row));
            }
        image1.show();
            image1.saveRoi();


    }
}