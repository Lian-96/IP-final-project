package com.company;

import ij.plugin.filter.PlugInFilter;
import ij.ImagePlus;
import ij.process.ImageProcessor;
import ij.process.ByteProcessor;
import ij.IJ;
import ij.plugin.PlugIn;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;

public class NormHist6 implements PlugIn {
    double [] hist = new double[256];
    String path = "/Users/gurgenhakobyan/Desktop/HomeWork1/" ;


    public void run(String args) {
        try {
            Scanner input = new Scanner(new File( path +"5Lhist.txt"));

            while (input.hasNext()) {
                int i = input.nextInt();
                int val = input.nextInt();
                if(i == 0) {
                    hist[i] = val;
                } else {
                    hist[i] = hist[i - 1] + val;
                }
            }

            FileWriter output = new FileWriter(path + "6normEqL.txt");
            int numPixel = (int)hist[hist.length - 1];
            for(int i = 0; i < hist.length; i++) {
                hist[i] /= numPixel;
                output.write(i + "\t" + hist[i] + "\n");
            }

            output.flush();
        }
        catch (IOException e) {
            IJ.log(e.getMessage());
        }
        catch (Exception e) {
            IJ.log("Exception");
        }

    }

}